

let box = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
let currentPlayer = "X";

function allboxs() {
    console.log(`
___________
| ${box[0]} | ${box[1]} | ${box[2]} |
___________
| ${box[3]} | ${box[4]} | ${box[5]} |
___________
| ${box[6]} | ${box[7]} | ${box[8]} |
___________
`);
}


for (let i = 0; i < 9; i++) {

    allboxs(); 3

    let input = prompt("enter number 1  to 9 :");
    let index = input - 1;


    if (box[index] === "X" || box[index] === "O") {
        alert("Already filled! Try again");
        i--;
        continue;
    }

    box[index] = currentPlayer;


    currentPlayer = currentPlayer === "X" ? "O" : "X";
}

allboxs();

